//package pack;
//
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//
//public class MakeAPI {
//
//    @RequestMapping("/")
//    public Data data(@RequestParam(value="Bank", defaultValue = "") String Bank,
//                           @RequestParam(value="IFSC", defaultValue = "") String Ifsc,
//                           @RequestParam(value="Branch", defaultValue = "") String Branch,
//                           @RequestParam(value="Address", defaultValue = "") String Address,
//                           @RequestParam(value="Contact", defaultValue = "") String Contact,
//                           @RequestParam(value="City", defaultValue = "") String City,
//                           @RequestParam(value="District", defaultValue = "") String District,
//                           @RequestParam(value="State", defaultValue = "") String State){
//        return new Data(Bank,Ifsc,Branch,Address,Contact,City,District,State);
//    }
//}
