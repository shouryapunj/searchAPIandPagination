package pack;

import org.springframework.stereotype.Component;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

@Component
public class Find {




    public List<Data> d(String a) {
        String ifsc = a;
//        String b = null;
        List<Data> dataList = new ArrayList<Data>();
        String db_name = "db";
        final String jdbcDriver = "com.mysql.jdbc.Driver";
        final String dbUrl = "jdbc:mysql://localhost:3306/" + db_name;
        final String user = "root";
        final String pass = "root";
        Connection conn = null;
        Statement stmt = null;
        String query;
//        String searchString;
        Scanner scanIfsc = new Scanner(System.in);

        try {
            Class.forName(jdbcDriver);
            conn = DriverManager.getConnection(dbUrl, user, pass);
            stmt = conn.createStatement();

            //System.out.println("Enter the Bank name : ");
            //searchString = scanIfsc.next();

                query = "Select * from bankdata where IFSC like '%" + ifsc + "%'";

//            query = "select * from bankdata where bank like \"" + searchString + "\"";
            stmt.executeQuery(query);

            ResultSet res = stmt.executeQuery(query);

            while (res.next()) {
                Data data = new Data();
                data.setBank(res.getString("BANK"));
//             data.setBank(); = res.getString("BANK");
                data.setIfsc(res.getString("IFSC"));
                data.setBranch(res.getString("BRANCH"));
                data.setAddress(res.getString("ADDRESS"));
                data.setContact(res.getString("CONTACT"));

                data.setCity(res.getString("CITY"));
                data.setDistrict(res.getString("DISTRICT"));

                data.setState(res.getString("STATE"));

                System.out.print("Bank = " + data.getBank() + "\nIFSC = " + data.getIfsc() + "\nBranch = " + data.getBranch() + "\nAddress = " + data.getAddress() + "\nContact = " + data.getContact() + "\nCity = " + data.getCity() + "\nDistrict = " + data.getDistrict() + "\nState = " + data.getState());

                dataList.add(data);
            }
            res.close();

        } catch (SQLException se) {
            se.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            //finally block to close conn
            try {
                if (stmt != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }


        }
        return dataList;

    }

}