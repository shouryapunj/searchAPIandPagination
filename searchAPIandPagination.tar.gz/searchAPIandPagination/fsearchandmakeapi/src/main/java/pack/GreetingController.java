package pack;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class GreetingController {

    @Autowired
    private Find d;

    @RequestMapping(
            value = "/IFSC",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE
    )

//    ResponseEntity<HTMLOUt> calcInp(@RequestParam String inputIFSC)
    ResponseEntity<List<Data>> calcInp(@RequestParam String ifsc) {
        List<Data> data = d.d(ifsc);
        //Find f = new Find();
        //f.d(ifsc);
        // Save in DB

        return ResponseEntity.ok(data);

//            return data(Ifsc);
    }
}